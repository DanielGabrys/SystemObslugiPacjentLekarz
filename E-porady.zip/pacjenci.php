<?php

session_start();
require_once "conected.php";

$ID=$_SESSION['Id'];
$tab=NULL;
$choroby=NULL;
$test=NULL;

function tablica(&$tablica,$rezultat) //zapelniamy tablice danymi
{
  $licz=0; 
			
		while($row = mysqli_fetch_assoc($rezultat)) //specjalizacje
		{
			 
			$tablica[$licz]=$row;
			$licz++;
			  
		}  
}

function wypisz($ile0,$tab)
{
    $i=0;
	?><div class="blok0"> </div> <?php
	while($i<$ile0)
		{	
		?> <div class="blok"> <?php
		echo "Pesel: ".$tab[$i]['Pesel'].", "."Imie: ".$tab[$i]['Name']."</br></br>"
		?> <a href="pacjent_profil.php?value=<?php echo $tab[$i]['Id']?>"> <button>Podglad</button></a> 
		</div>
		<?php
		$i++;
		}
}

function requires($tab,$zapyt,$s,$u,$p,$d)
{
	mysqli_report(MYSQLI_REPORT_STRICT);
	try
	{
	    
		$con= new mysqli($s,$u,$p,$d);
		if($con->connect_errno!=0)
		{
			throw new Exception(mysqli_connect_errno());
		}
		else
		{
		    $rez=$con->query($zapyt);
    		if(!$rez) throw new Exception($con->error);
    		
            $ile=$rez->num_rows;
    		tablica($tab,$rez);
    		
    		$con->close();
		}
	}
	catch(Exception $e)
	{
		echo '<span style="color:red;">Blad serwera </span>';
		echo '<br/>'.$e;
	}  
}

///////////////////////////////////////////////////////////////
$zap1="SELECT *FROM customers";
requires($test,$zap1,$servername,$username,$password,$database);

require_once "conected.php"; //jak pierwszy raz wchodzimy do widzimy liste wszystkich pacjentow
	mysqli_report(MYSQLI_REPORT_STRICT);
	try
	{
		$con= new mysqli($servername,$username,$password,$database);
		if($con->connect_errno!=0)
		{
			throw new Exception(mysqli_connect_errno());
		}
		else
		{
		    //szukamy pacjentow przypisanych do danego lekarza
		    $rezx=$con->query("SELECT customers.Name,customers.Pesel,customers.Id,lekarze.ID FROM pacjenci JOIN customers ON
		    customers.Id = pacjenci.cus_id JOIN lekarze ON lekarze.ID = pacjenci.lekarz_id WHERE lekarze.ID='$ID' ORDER BY Name");
    		if(!$rezx) throw new Exception($con->error);
    		
            $ilex=$rezx->num_rows;
            //// ciag id do pokazania pacjentow przypisanych do danego lekarza

             $licz=0; //normalnie reszta rezulatow jest da dole jest ten musibyc widoczny
             $element="";
	         $element2=',';	
			while($row = mysqli_fetch_assoc($rezx))
			{
			   $tabx[$licz]=$row;
			   $element.=$tabx[$licz]['Id']; 
			   if($licz!=$ilex-1 )
			     $element.=$element2;
			   
			    $licz++;
			}
			
	        //echo $element;
	        if($ilex==0) //jezeli lekarz nie ma przypisanych pacjentow
	        $element=0;
            
            
    		$rez0=$con->query("SELECT Name,Pesel,Id From customers WHERE Id IN ($element)");
    		if(!$rez0) throw new Exception($con->error);
    		
    		$ile0=$rez0->num_rows;
    		
    		//wszystkie choroby
    		$rez_chor=$con->query("SELECT DISTINCT choroby.choroba FROM choroby_pacjenci JOIN customers ON customers.Id = choroby_pacjenci.cus_id JOIN choroby ON choroby.chor_id = choroby_pacjenci.chor_id ORDER BY choroba");
    		if(!$rez_chor) throw new Exception($con->error);
    		
    		$ile_chor=$rez_chor->num_rows;
    		tablica($choroby,$rez_chor);
    		
    		$con->close();
		}
	}
	catch(Exception $e)
	{
		echo '<span style="color:red;">Blad serwera </span>';
		echo '<br/>'.$e;
	}

/////////
if(isset($_POST['pacjent']) )
{
$ok=true;
$all=0;

$pacjent=$_POST['pacjent'];
if($pacjent!='wszyscy')
  $fraza_p="customers.Name="."'".$pacjent."' "."AND";
else
{
  $fraza_p="";
  $all++;
}

$choroba=$_POST['choroba'];
if($choroba!='wszystkie')
  $fraza_c="choroby.choroba="."'".$choroba."' "."AND";
else
  {
      $fraza_c="";
      $all++;
  }
 
$status=$_POST['status'];
if($status!='wszystkie')
  $fraza_s="choroby_pacjenci.status="."'".$status."' "."AND";
else
  {
      $fraza_s="";
      $all++;
  }
  
if($pacjent=="wszyscy" && $choroba=="wszystkie" && $status=="wszystkie")
    $fraza0="AND";
else
    $fraza0="WHERE";


require_once "conected.php";
	mysqli_report(MYSQLI_REPORT_STRICT);
	try
	{
		$con= new mysqli($servername,$username,$password,$database);
		if($con->connect_errno!=0)
		{
			throw new Exception(mysqli_connect_errno());
		}
		else
		{
		    
		//serce wyszukiwarki
		if($pacjent!='wszyscy' && $choroba=='wszystkie' && $status=='wszystkie')
		{
        $zapytanie=""."SELECT Name,Pesel,Id FROM customers WHERE Name=".'"'.$pacjent.'"'."";
		}
		else
		{
		$zapytanie=""."SELECT customers.Name,customers.Pesel,customers.Id,choroby.choroba FROM choroby_pacjenci JOIN customers ON
		customers.Id = choroby_pacjenci.cus_id JOIN choroby ON choroby.chor_id = choroby_pacjenci.chor_id "."$fraza0 "."$fraza_p "
		.""."$fraza_c "."$fraza_s "." customers.Id IN (".$element.")"."";  
		}
		//echo $zapytanie;
		$rez_wynik=$con->query($zapytanie);
		if(!$rez_wynik) throw new Exception($con->error);

			$ile_wynik=$rez_wynik->num_rows;

			if($ile_wynik==0)       //nie znaleziono
			{
			 $ok=false;
			 $_SESSION['blad']="nie znaleziono";
			}
		
		   else
					
			{
			    tablica($tab,$rez_wynik);
			}

	
                        
			$con->close();
		}
	}
	catch(Exception $e)
	{
		echo '<span style="color:red;">Blad serwera </span>';
		echo '<br/>'.$e;
	}
}	
   		

?>
<!DOCTYPE html>
<html>
<body>
    
<a href="main_dc.php"> <button > Powrót </button> </br> </a>
<h2>Pacjenci</h2>
<form method="post">

Pacjent:
<td>  <select name="pacjent">
      
<?php
    $pacjent_opcja="0";
    if(isset($_POST['pacjent']))
    { ?>
    <option value ="<?php echo $_POST['pacjent'];?>" > <?php echo $_POST['pacjent'];
    $pacjent_opcja=$_POST['pacjent']; //zapamietanie aktualnej opcji
    } ?>
    
	<?php if($pacjent_opcja!="wszyscy"){?> <option value ="wszyscy">wszyscy 
	
	<?php }
	for ($i=0;$i<$ilex;$i++)
	    {   
	    if($pacjent_opcja!=$tabx[$i]['Name'])
	    {
	    ?>
    	<option value ="<?php echo $tabx[$i]['Name'];?>"> <?php echo $tabx[$i]['Name'];?>
	    <?php
	    }
	    }   ?>
	
	</select>
Choroba:
 <td>  <select name="choroba">
      
<?php
    $choroba_opcja="0";
    if(isset($_POST['choroba']))
    { ?>
    <option value ="<?php echo $_POST['choroba'];?>" > <?php echo $_POST['choroba'];
    $choroba_opcja=$_POST['choroba']; //zapamietanie aktualnej opcji
    } ?>
    
	<?php if($choroba_opcja!="wszystkie"){?> <option value ="wszystkie">wszystkie
	
	<?php }
	for ($i=0;$i<$ile_chor;$i++)
	    {   
	    if($choroba_opcja!=$choroby[$i]['choroba'])
	    {
	    ?>
    	<option value ="<?php echo $choroby[$i]['choroba'];?>"> <?php echo $choroby[$i]['choroba'];?>
	    <?php
	    }
	    }   ?>
	
	</select>
	
  </td>
  
  Status:
  <td>  <select name="status">
      
    <?php
    $status_opcja="0";
    if(isset($_POST['status']))
    { ?>
    <option value ="<?php echo $_POST['status'];?>" > <?php echo $_POST['status'];
    $status_opcja=$_POST['status']; //zapamietanie aktualnej opcji
    } 
    
	if($status_opcja!="wszystkie") { ?> <option value ="wszystkie">wszystkie <?php } 
	if($status_opcja!="chory") { ?> <option value ="chory">chory <?php } 
	if($status_opcja!="wyleczony") { ?> <option value ="wyleczony">wyleczony <?php } ?>

	</select>
  </td> </br> </br>
  
<input type="submit" name="Szukaj" value="SZUKAJ">
<input type="submit" name="wszyscy" value="Pokaz wszystkich pacjentow"> </br>
</form> </br>
<?php

if(isset($_SESSION['blad']) && !isset($_POST['wszyscy'])) //jezeli blad
	{	
		echo $_SESSION['blad'];
		unset($_SESSION['blad']);
	}

else if(isset($_POST['wszyscy']) || !isset($_POST['pacjent']) || $all==3) //jezeli kliknieto przycisk pokaz wszystkich pascjentow lub pierwsze odwiedze niestrony lub wszystko jest ustawione na wartosc wszystkie($all==3)
	{
		if($ile0>0)
		{
		unset($_SESSION['blad']);
		$licz=0;
				
			while($row = mysqli_fetch_assoc($rez0))
			{
			    $tab[$licz]=$row;
				$licz++;		
			}
		}	
     wypisz($ile0,$tab);
	}
else
{
     wypisz($ile_wynik,$tab);	
}
?>
</body>
</html>

<style>
    .blok0, .blok
    {
    border-top: 3px solid black; 
    background:grey;
    display: block;
    width:50%;
    }
    
   .blok
   {
       border-left: 3px solid black;
       border-right: 3px solid black;
       border-bottom: 3px solid black;
   }
   
   .blok0
    {
    border-top: 3px solid black; 
    }
    
</style>
