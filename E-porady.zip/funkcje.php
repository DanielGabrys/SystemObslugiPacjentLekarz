<?php
function tablica(&$tablica,$rezultat) //zapelniamy tablice danymi
{
  $licz=0; 
			
		while($row = mysqli_fetch_assoc($rezultat)) //specjalizacje
		{
			 
			$tablica[$licz]=$row;
			$licz++;
			  
		}  
}

function wypisz($ile,$tab) //wypisanie wynikow wyszukiwania
{
    $i=0;
	?><div class="blok0"> </div> <?php
	while($i<$ile)
		{	
		?> <div class="blok"> <?php
		echo "Pesel: ".$tab[$i]['Pesel'].", "."Imie: ".$tab[$i]['Name']."</br></br>"
		?> <a href="pacjent_profil.php?value=<?php echo $tab[$i]['Id']?>"> <button>Podglad</button></a> 
		</div>
		<?php
		$i++;
		}
}

function requires(&$tab,$zapyt,$s,$u,$p,$d) //zapytanie do bazy danych
{
    $ile=0;
	mysqli_report(MYSQLI_REPORT_STRICT);
	try
	{
	    
		$con= new mysqli($s,$u,$p,$d);
		if($con->connect_errno!=0)
		{
			throw new Exception(mysqli_connect_errno());
		}
		else
		{
		    $rez=$con->query($zapyt);
    		if(!$rez) throw new Exception($con->error);
    		
            $ile=$rez->num_rows;
    		tablica($tab,$rez);
    		
    		$con->close();
		}
	}
	catch(Exception $e)
	{
		echo '<span style="color:red;">Blad serwera </span>';
		echo '<br/>'.$e;
	}  
	return $ile;
}

function element($tab,$ile) //ciag ID przypisanych pacjentowdo lekarza
{
    $element="";
	$element2=',';	
	for($i=0;$i<$ile;$i++)
		{
			$element.=$tab[$i]['Id']; 
			if($i!=$ile-1 )
			    $element.=$element2;
		}
			
	   if($ile==0) //jezeli lekarz nie ma przypisanych pacjentow
	        $element=0; 
	        
	return $element;
}
