<style>
A {text-decoration: none;}

#block, #block2, #block3
{
    display: block;
    border: none;
    color: white;
    padding: 14px 28px;
    font-size: 16px;
    cursor: pointer;
    text-align: center;
    float:left;
}

#block, #block2
{
    width: 23%; 
}

#block3
{
    width: 8%; 
}

#block
{
    <?php
    if($ile!=0)
        {?> 
        background-color: #4CAF50;
        <?php }
    else
        {?>
        background-color: grey; 
        <?php }
    ?>
}

#block2, #block3
{
  background-color: grey;
}

#block:hover,#block2:hover,#block3:hover
{
  background-color: #ddd;
  color: black;
}

#imie
{
    background-color:#ddd;
    
}

#text
{
    margin-left:10px;
}

</style>