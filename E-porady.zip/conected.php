<?php

$servername = "localhost";
$database = "id15523904_baza_uzytkownicy";
$username = "id15523904_daniel";
$password = "Teoriakwantowa1.";
?>
